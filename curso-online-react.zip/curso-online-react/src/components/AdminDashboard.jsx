import React from 'react';

export default function AdminDashboard({ usuariosAdmin, aprobarCuentaUsuario, cambiarRolUsuario, eliminarUsuario, cursosDisponibles, seccionActiva, eliminarCurso }) {
  // KPIs dinámicos
  const totalUsuarios = usuariosAdmin.length;
  const totalAprobados = usuariosAdmin.filter(u => u.estado === 'APROBADA').length;
  const totalPendientes = usuariosAdmin.filter(u => u.estado !== 'APROBADA').length;
  const totalCursos = cursosDisponibles ? cursosDisponibles.length : 0;

  return (
    <div className="h-100 overflow-y-auto">
      {/* TARJETAS DE ESTADÍSTICAS (KPIs) */}
      <div className="row g-3 mb-4">
        <div className="col-md-3">
          <div className="card border-0 shadow-sm p-3 bg-light rounded-3">
            <small className="text-muted fw-bold">TOTAL USUARIOS</small>
            <h3 className="fw-bold text-dark mt-1 mb-0">{totalUsuarios}</h3>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 shadow-sm p-3 bg-light rounded-3">
            <small className="text-muted fw-bold">APROBADOS</small>
            <h3 className="fw-bold text-success mt-1 mb-0">{totalAprobados}</h3>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 shadow-sm p-3 bg-light rounded-3">
            <small className="text-muted fw-bold">PENDIENTES</small>
            <h3 className="fw-bold text-warning mt-1 mb-0">{totalPendientes}</h3>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 shadow-sm p-3 bg-light rounded-3">
            <small className="text-muted fw-bold">CURSOS CREADOS</small>
            <h3 className="fw-bold text-primary mt-1 mb-0">{totalCursos}</h3>
          </div>
        </div>
      </div>

      {/* VISTA 1: GESTIÓN DE USUARIOS */}
      {seccionActiva === 'usuarios' && (
        <div>
          <div className="mb-3">
            <h4 className="fw-bold text-dark mb-1">Usuarios del Sistema</h4>
            <p className="text-muted small mb-0">Administra las cuentas, aprueba accesos y cambia los roles de los usuarios registrados.</p>
          </div>

          <div className="table-responsive">
            <table className="table align-middle table-hover border-top">
              <thead className="table-dark">
                <tr>
                  <th className="py-3"># ID</th>
                  <th className="py-3">Nombre y Correo</th>
                  <th className="py-3">Estado</th>
                  <th className="py-3">Rol Actual</th>
                  <th className="py-3 text-end">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {usuariosAdmin.map(u => (
                  <tr key={u.id}>
                    <td className="fw-semibold text-secondary">#{u.id}</td>
                    <td>
                      <div className="fw-bold text-dark">{u.nombre}</div>
                      <small className="text-muted">{u.correo}</small>
                    </td>
                    <td>
                      <span className={`badge px-2 py-1 ${u.estado === 'APROBADA' ? 'bg-success-subtle text-success border border-success-subtle' : 'bg-warning-subtle text-warning border border-warning-subtle'}`}>
                        {u.estado || 'PENDIENTE'}
                      </span>
                    </td>
                    <td>
                      <select 
                        className="form-select form-select-sm shadow-sm" 
                        style={{ width: '140px' }}
                        value={u.rol || 'ESTUDIANTE'} 
                        onChange={(e) => cambiarRolUsuario(u.id, e.target.value)}>
                        <option value="ESTUDIANTE">ESTUDIANTE</option>
                        <option value="PROFESOR">PROFESOR</option>
                        <option value="ADMIN">ADMIN</option>
                      </select>
                    </td>
                    <td className="text-end">
                      <div className="d-flex justify-content-end gap-2">
                        {u.estado !== 'APROBADA' && (
                          <button className="btn btn-success btn-sm px-3 shadow-sm" onClick={() => aprobarCuentaUsuario(u.id)}>
                            Aprobar
                          </button>
                        )}
                        <button className="btn btn-outline-danger btn-sm px-3 shadow-sm" onClick={() => eliminarUsuario(u.id)}>
                          Eliminar
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VISTA 2: CATÁLOGO DE CURSOS CON BOTÓN DE ELIMINAR */}
      {seccionActiva === 'cursos' && (
        <div>
          <div className="mb-3">
            <h4 className="fw-bold text-dark mb-1">Cursos Registrados en la Plataforma</h4>
            <p className="text-muted small mb-0">Visualiza y administra todas las materias impartidas por los profesores.</p>
          </div>

          {!cursosDisponibles || cursosDisponibles.length === 0 ? (
            <div className="text-center py-5 bg-light rounded text-muted">No hay cursos registrados en el sistema actualmente.</div>
          ) : (
            <div className="row g-3">
              {cursosDisponibles.map(c => (
                <div className="col-md-6" key={c.id}>
                  <div className="card border-0 shadow-sm p-4 h-100 bg-light d-flex flex-column justify-content-between">
                    <div>
                      <div className="d-flex justify-content-between align-items-start mb-2">
                        <h5 className="fw-bold text-dark mb-0">{c.nombre || c.titulo}</h5>
                        <span className="badge bg-primary text-white px-3 py-2">$ {c.precio}</span>
                      </div>
                      <p className="text-muted small mb-3">{c.descripcion}</p>
                    </div>
                    <div className="d-flex justify-content-between align-items-center mt-3 pt-3 border-top border-secondary-subtle">
                      <small className="text-secondary fw-semibold">ID del Curso: #{c.id}</small>
                      {/* 🗑️ BOTÓN DE ELIMINAR CURSO */}
                      <button 
                        className="btn btn-outline-danger btn-sm px-3 shadow-sm"
                        onClick={() => eliminarCurso(c.id)}>
                        Eliminar Curso
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}