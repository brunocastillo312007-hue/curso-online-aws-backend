import React from 'react';

export default function EstudianteDashboard({ misInscripciones, cancelarInscripcion, cursosDisponibles, inscribirCurso }) {
  return (
    <div>
      <h5 className="fw-bold text-dark mb-3">📚 Mis Cursos Matriculados</h5>
      {misInscripciones.length === 0 ? (
        <div className="alert alert-light border text-muted py-3 mb-5">No estás inscrito en ningún curso actualmente. ¡Explora el catálogo abajo!</div>
      ) : (
        <div className="row g-3 mb-5">
          {misInscripciones.map(item => (
            <div className="col-md-6" key={item.id}>
              <div className="card border-0 shadow-sm p-4 bg-success-subtle bg-opacity-10 border-start border-success border-4">
                <h6 className="fw-bold text-dark">{item.curso?.nombre || item.curso?.titulo}</h6>
                <p className="text-muted small mb-3">{item.curso?.descripcion}</p>
                <div>
                  <button className="btn btn-outline-danger btn-sm" onClick={() => cancelarInscripcion(item.id)}>
                    Cancelar Matrícula
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <h5 className="fw-bold text-dark mb-3">🔍 Catálogo de Cursos Disponibles</h5>
      <div className="row g-3">
        {cursosDisponibles.map(c => (
          <div className="col-md-6" key={c.id}>
            <div className="card border-0 shadow-sm p-4 h-100">
              <div className="d-flex justify-content-between align-items-start mb-2">
                <h6 className="fw-bold text-dark mb-0">{c.nombre || c.titulo}</h6>
                <span className="badge bg-success text-white">$ {c.precio}</span>
              </div>
              <p className="text-muted small mb-4">{c.descripcion}</p>
              <div className="mt-auto">
                <button className="btn btn-success btn-sm w-100 shadow-sm" onClick={() => inscribirCurso(c.id)}>
                  Inscribirse al Curso
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}