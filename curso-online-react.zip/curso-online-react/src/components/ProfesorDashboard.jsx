import React from 'react';

export default function ProfesorDashboard({ nuevoCurso, setNuevoCurso, registrarCurso, misCursosProf, misInscripciones }) {
  return (
    <div>
      {/* Formulario de creación de cursos */}
      <div className="card bg-white border border-light-subtle shadow-sm p-4 mb-5">
        <h5 className="fw-bold text-primary mb-3">✨ Crear Nuevo Curso</h5>
        <form onSubmit={registrarCurso}>
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label small fw-bold text-muted">Título</label>
              <input className="form-control" placeholder="Ej. Spring Boot Avanzado" value={nuevoCurso.titulo} onChange={e => setNuevoCurso({...nuevoCurso, titulo: e.target.value})} required />
            </div>
            <div className="col-md-6">
              <label className="form-label small fw-bold text-muted">Nombre del Curso</label>
              <input className="form-control" placeholder="Ej. Backend Java" value={nuevoCurso.nombre} onChange={e => setNuevoCurso({...nuevoCurso, nombre: e.target.value})} required />
            </div>
            <div className="col-12">
              <label className="form-label small fw-bold text-muted">Descripción</label>
              <textarea className="form-control" rows="2" placeholder="Detalles del contenido..." value={nuevoCurso.descripcion} onChange={e => setNuevoCurso({...nuevoCurso, descripcion: e.target.value})} required />
            </div>
            <div className="col-md-6">
              <label className="form-label small fw-bold text-muted">Precio ($)</label>
              <input className="form-control" type="number" placeholder="0.00" value={nuevoCurso.precio} onChange={e => setNuevoCurso({...nuevoCurso, precio: Number(e.target.value)})} required />
            </div>
            <div className="col-md-6 d-flex align-items-end">
              <button className="btn btn-primary w-150 py-2 shadow-sm" type="submit">Publicar Curso</button>
            </div>
          </div>
        </form>
      </div>

      {/* Mis Cursos Impartidos */}
      <h5 className="fw-bold text-dark mb-3">📚 Mis Cursos Impartidos</h5>
      <div className="row g-3 mb-5">
        {misCursosProf.map(c => (
          <div className="col-md-6" key={c.id}>
            <div className="card border-0 shadow-sm p-4 h-100 bg-light">
              <div className="d-flex justify-content-between align-items-start mb-2">
                <h6 className="fw-bold text-dark mb-0">{c.nombre || c.titulo}</h6>
                <span className="badge bg-primary text-white">$ {c.precio}</span>
              </div>
              <p className="text-muted small mb-3">{c.descripcion}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Alumnos Matriculados */}
      <h5 className="fw-bold text-dark mb-3">👨‍🎓 Alumnos Matriculados en Mis Cursos</h5>
      {misInscripciones.length === 0 ? (
        <div className="text-center py-4 bg-light rounded text-muted">No hay estudiantes inscritos en tus cursos actualmente.</div>
      ) : (
        <div className="table-responsive">
          <table className="table align-middle table-hover">
            <thead>
              <tr>
                <th className="py-3">ID</th>
                <th className="py-3">Estudiante</th>
                <th className="py-3">Correo</th>
                <th className="py-3">Curso Asignado</th>
              </tr>
            </thead>
            <tbody>
              {misInscripciones.map(ins => (
                <tr key={ins.id}>
                  <td className="fw-semibold text-secondary">#{ins.id}</td>
                  <td className="fw-bold text-dark">{ins.estudiante?.nombre || 'Estudiante'}</td>
                  <td className="text-muted">{ins.estudiante?.correo || 'N/D'}</td>
                  <td>
                    <span className="badge bg-info-subtle text-info border border-info-subtle px-2 py-1">
                      {ins.curso?.nombre || ins.curso?.titulo || 'Curso'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}