import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { apiService } from '../services/api.service';

import App from '../App';
import AdminDashboard from '../components/AdminDashboard';
import ProfesorDashboard from '../components/ProfesorDashboard';
import EstudianteDashboard from '../components/EstudianteDashboard';

// 🧭 NUEVA VISTA PROTEGIDA CON MENÚ LATERAL (SIDEBAR)
const VistaConSidebar = ({ rolRequerido, children, seccionActiva, setSeccionActiva }) => {
  const token = localStorage.getItem('token');
  const rolActual = localStorage.getItem('rol');
  const nombreUsuario = localStorage.getItem('nombre') || 'Usuario';

  if (!token) return <Navigate to="/" replace />;
  if (rolRequerido && rolActual !== rolRequerido) return <Navigate to="/" replace />;

  const cerrarSesion = () => {
    localStorage.clear();
    window.location.href = '/';
  };

  return (
    <div className="container-fluid vh-100 p-0 m-0 overflow-hidden bg-light">
      <div className="row h-100 g-0">
        
        {/* MENÚ LATERAL (SIDEBAR) CON DEGRADADO AZUL */}
        <div className="col-md-3 col-lg-2 text-white d-flex flex-column p-4 shadow" 
             style={{ 
               background: 'linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #3b82f6 100%)' 
             }}>
          
          {/* Logo / Título */}
          <div className="mb-4 pb-3 border-bottom border-white border-opacity-25">
            <h5 className="fw-bold text-white mb-1">🎓 CursoOnline</h5>
            <small className="text-white-50 text-uppercase" style={{ fontSize: '0.7rem' }}>Panel de {rolActual}</small>
          </div>

          {/* Opciones de Navegación según el Rol */}
          <div className="nav flex-column gap-2 mb-auto">
            {rolActual === 'ADMIN' && (
              <>
                <button 
                  className={`btn text-start w-100 py-2 px-3 fw-semibold border-0 ${seccionActiva === 'usuarios' ? 'bg-white text-primary shadow-sm' : 'text-white bg-transparent'}`}
                  onClick={() => setSeccionActiva('usuarios')}>
                  👥 Usuarios
                </button>
                <button 
                  className={`btn text-start w-100 py-2 px-3 fw-semibold border-0 ${seccionActiva === 'cursos' ? 'bg-white text-primary shadow-sm' : 'text-white bg-transparent'}`}
                  onClick={() => setSeccionActiva('cursos')}>
                  📚 Cursos del Sistema
                </button>
              </>
            )}

            {rolActual === 'PROFESOR' && (
              <>
                <button className="btn bg-white text-primary text-start w-100 py-2 px-3 fw-semibold mb-1 shadow-sm border-0">
                  📚 Mis Cursos y Alumnos
                </button>
              </>
            )}

            {rolActual === 'ESTUDIANTE' && (
              <>
                <button className="btn bg-white text-primary text-start w-100 py-2 px-3 fw-semibold mb-1 shadow-sm border-0">
                  🎓 Mis Matrículas y Catálogo
                </button>
              </>
            )}
          </div>

          {/* Información del Usuario y Botón de Salida */}
          <div className="pt-3 border-top border-white border-opacity-25 mt-auto">
            <div className="d-flex align-items-center mb-3">
              <div className="bg-white text-primary rounded-circle d-flex align-items-center justify-content-center fw-bold me-2 shadow-sm" style={{ width: '35px', height: '35px', fontSize: '0.9rem' }}>
                {nombreUsuario.charAt(0).toUpperCase()}
              </div>
              <div className="overflow-hidden">
                <h6 className="mb-0 text-white text-truncate small fw-bold">{nombreUsuario}</h6>
                <small className="text-white-50 text-truncate d-block" style={{ fontSize: '0.75rem' }}>{rolActual}</small>
              </div>
            </div>
            <button onClick={cerrarSesion} className="btn btn-outline-light btn-sm w-100 py-2 border-opacity-50">
              Cerrar Sesión
            </button>
          </div>
        </div>

        {/* CONTENEDOR PRINCIPAL DERECHO */}
        <div className="col-md-9 col-lg-10 h-100 overflow-y-auto p-4 p-lg-5">
          <div className="card border-0 shadow-sm p-4 bg-white rounded-4 h-100">
            {children}
          </div>
        </div>

      </div>
    </div>
  );
};

// Contenedor inteligente para ADMIN
const AdminVista = () => {
  const [usuariosAdmin, setUsuariosAdmin] = useState([]);
  const [cursosDisponibles, setCursosDisponibles] = useState([]);
  const [seccionActiva, setSeccionActiva] = useState('usuarios');
  const [cargando, setCargando] = useState(true);

  const cargarDatosAdmin = async () => {
    try {
      const resUsr = await apiService.obtenerUsuariosAdmin();
      setUsuariosAdmin(resUsr.data);
      const resCat = await apiService.obtenerCatalogoCursos();
      setCursosDisponibles(resCat.data);
    } catch (err) {
      console.error("Error al cargar datos");
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => { cargarDatosAdmin(); }, []);

  const aprobar = async (id) => {
    await apiService.aprobarUsuario(id);
    cargarDatosAdmin();
  };

  const cambiarRol = async (id, rol) => {
    await apiService.actualizarRolUsuario(id, rol);
    cargarDatosAdmin();
  };

  const eliminarUsuario = async (id) => {
    if (!window.confirm("¿Estás seguro de eliminar este usuario?")) return;
    await apiService.eliminarUsuarioAdmin(id);
    cargarDatosAdmin();
  };

  const eliminarCurso = async (idCurso) => {
    if (!window.confirm("¿Estás seguro de eliminar este curso del sistema?")) return;
    try {
      // Llamamos al método correcto que tienes en tu api.service.js
      await apiService.eliminarCursoAdmin(idCurso);
      
      // Recargamos los datos para que desaparezca de la tabla inmediatamente
      cargarDatosAdmin();
    } catch (err) {
      console.error("Error al eliminar el curso:", err);
      alert("No se pudo eliminar el curso.");
    }
  };

  if (cargando) return <p className="text-center text-muted mt-5">Cargando panel...</p>;

  return (
    <VistaConSidebar rolRequerido="ADMIN" seccionActiva={seccionActiva} setSeccionActiva={setSeccionActiva}>
      <AdminDashboard 
        usuariosAdmin={usuariosAdmin} 
        aprobarCuentaUsuario={aprobar} 
        cambiarRolUsuario={cambiarRol} 
        eliminarUsuario={eliminarUsuario} 
        cursosDisponibles={cursosDisponibles}
        seccionActiva={seccionActiva}
        eliminarCurso={eliminarCurso}
      />
    </VistaConSidebar>
  );
};

// Contenedor inteligente para PROFESOR
const ProfesorVista = () => {
  const [misCursosProf, setMisCursosProf] = useState([]);
  const [misInscripciones, setMisInscripciones] = useState([]);
  const [nuevoCurso, setNuevoCurso] = useState({ titulo: '', nombre: '', descripcion: '', precio: 0 });
  const [cargando, setCargando] = useState(true);

  const cargarDatosProfesor = async () => {
    try {
      const resProf = await apiService.obtenerMisCursosProfesor();
      setMisCursosProf(resProf.data);
      const resInsP = await apiService.obtenerInscripcionesProfesor();
      setMisInscripciones(resInsP.data);
    } catch (err) {
      console.error("Error al cargar datos");
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => { cargarDatosProfesor(); }, []);

  const registrarCurso = async (e) => {
    e.preventDefault();
    await apiService.crearCurso(nuevoCurso);
    setNuevoCurso({ titulo: '', nombre: '', descripcion: '', precio: 0 });
    cargarDatosProfesor();
  };

  if (cargando) return <p className="text-center text-muted mt-5">Cargando panel...</p>;

  return (
    <VistaConSidebar rolRequerido="PROFESOR">
      <ProfesorDashboard 
        nuevoCurso={nuevoCurso} 
        setNuevoCurso={setNuevoCurso} 
        registrarCurso={registrarCurso} 
        misCursosProf={misCursosProf} 
        misInscripciones={misInscripciones} 
      />
    </VistaConSidebar>
  );
};

// Contenedor inteligente para ESTUDIANTE
const EstudianteVista = () => {
  const [cursosDisponibles, setCursosDisponibles] = useState([]);
  const [misInscripciones, setMisInscripciones] = useState([]);
  const [cargando, setCargando] = useState(true);

  const cargarDatosEstudiante = async () => {
    try {
      const resCat = await apiService.obtenerCatalogoCursos();
      setCursosDisponibles(resCat.data);
      const resIns = await apiService.obtenerCursosEstudiante();
      setMisInscripciones(resIns.data);
    } catch (err) {
      console.error("Error al cargar datos");
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => { cargarDatosEstudiante(); }, []);

  const inscribir = async (id) => {
    await apiService.inscribirseCurso(id);
    cargarDatosEstudiante();
  };

  const cancelar = async (id) => {
    await apiService.eliminarInscripcion(id);
    cargarDatosEstudiante();
  };

  if (cargando) return <p className="text-center text-muted mt-5">Cargando panel...</p>;

  return (
    <VistaConSidebar rolRequerido="ESTUDIANTE">
      <EstudianteDashboard 
        misInscripciones={misInscripciones} 
        cancelarInscripcion={cancelar} 
        cursosDisponibles={cursosDisponibles} 
        inscribirCurso={inscribir} 
      />
    </VistaConSidebar>
  );
};

export default function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />} />
        <Route path="/admin" element={<AdminVista />} />
        <Route path="/profesor" element={<ProfesorVista />} />
        <Route path="/estudiante" element={<EstudianteVista />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}